The Xpt Folder contains a collection of SEND domain files in SAS transport format (.xpt).
These may be read using SAS, the SAS Universal Viewer (which is available from from SAS), or Instem's SENDView.  Please contact Instem to get more information about SENDView.
This folder also contains the data definition (define) file in both .pdf and .xml format.  
A stylesheet and icons are also included to allow define.xml to be viewed in a browser.
This define.xml is best viewed with internet explorer.  Right-click the file, select Open With... then select Internet Explorer.  
Other style sheets may be used as desired.


The Xlsx Folder contains an excel format of the SEND datset. There is one file, with each domain in a separate sheet.

contact submit@instem.com if there are any questions or issues about this dataset.

Instem
Diamond Way
Stone Business Park
Stone, Staffordshire
ST15 0SD
United Kingdom
+44 (0) 1785825600
